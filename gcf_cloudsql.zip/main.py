import os
import psycopg2
from psycopg2 import sql


# Configuration parameters
DB_USER = 'ajain53'      # e.g., 'postgres'
DB_PASS = 'Admin@12345'       # e.g., 'your-password'
DB_NAME = 'bq_to_cloudsql'       # e.g., 'your-database'
CLOUD_SQL_CONNECTION_NAME = 'slb-it-op-dev:europe-west1:poc-bq-to-sql'  # e.g., 'project:region:instance'
# Function to connect and query the database

# Your INSERT query
INSERT_QUERY = 'INSERT INTO orng_activity_equipment_f_curated SELECT * FROM  orng_activity_equipment_f;'

# Function to connect and execute the INSERT query
def run_insert_query(request):
    conn = None
    try:
        # Construct the connection string
        conn = psycopg2.connect(
            user=DB_USER,
            password=DB_PASS,
            dbname=DB_NAME,
            host=f"/cloudsql/{CLOUD_SQL_CONNECTION_NAME}"
        )

        # Create a cursor object
        with conn.cursor() as cursor:
            # Execute the INSERT query
            cursor.execute(INSERT_QUERY)
            conn.commit()  # Commit the changes
            
            return "Insert operation completed successfully.", 200

    except Exception as e:
        return f"Error: {str(e)}", 500

    finally:
        if conn:
            conn.close()
